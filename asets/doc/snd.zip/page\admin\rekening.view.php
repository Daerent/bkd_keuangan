<?php
if(!defined('BASEURL')){
  die("HAYOoo.. mau ngapain? (-_-')");
}
else{
  ?>#judul('Master Rekening & Belanja')
<div class="container mt-4">

  <h3 class="mb-lg-4">Master Data - Rekening & Belanja</h3>

  <!-- Alert Container -->
  <div id="alertContainer" data-aos="zoom-in"></div>

  <div class="card" data-aos="fade-up">
    <div class="card-header">
      <h5 class="card-title mb-0">Form Rekening & Belanja</h5>
    </div>
    <div class="card-body">
      <form class="row g-3" id="formRekening">
        <input type="hidden" name="id" id="rekening_id">
        <input type="hidden" name="a" value="simpan">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

        <div class="col-md-6">
          <label class="form-label">Kode Rekening <span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Contoh: 5.1.02.02.01.0080" name="kode_rekening" id="rekening_kode_rekening" required>
          <div class="invalid-feedback" id="rekening_kode_rekening_error"></div>
        </div>

        <div class="col-md-6">
          <label class="form-label">Nama Belanja <span class="text-danger">*</span></label>
          <input type="text" class="form-control" placeholder="Contoh: Belanja Honorarium Pengadaan Barang/Jasa" name="nama_belanja" id="rekening_nama_belanja" required>
          <div class="invalid-feedback" id="rekening_nama_belanja_error"></div>
        </div>

        <div class="col-12">
          <button type="submit" class="btn btn-primary">
            <span class="spinner-border spinner-border-sm d-none" role="status"></span>
            Simpan
          </button>
          <button type="button" class="btn btn-secondary" onclick="resetFormRekening()">Batal</button>
        </div>
      </form>
    </div>
  </div>

  <hr class="my-4">

  <div class="card" data-aos="fade-up">
    <div class="card-header">
      <h5 class="card-title mb-0">Daftar Rekening & Belanja</h5>
    </div>
    <div class="card-body">
      <!-- Search and Filter Section -->
      <div class="row mb-3">
        <div class="col-md-6">
          <div class="input-group">
            <input type="text" class="form-control search-input" placeholder="Cari kode rekening atau nama belanja..." data-tipe="rekening">
            <button class="btn btn-outline-primary search-btn" type="button" data-tipe="rekening">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              Cari
            </button>
          </div>
        </div>
        <div class="col-md-3">
          <select class="form-select search-field-select" data-tipe="rekening">
            <option value="">Semua Field</option>
            <option value="kode_rekening">Kode Rekening</option>
            <option value="nama_belanja">Nama Belanja</option>
          </select>
        </div>
        <div class="col-md-3">
          <select class="form-select per-page-select" data-tipe="rekening">
            <option value="10">10 per halaman</option>
            <option value="25">25 per halaman</option>
            <option value="50">50 per halaman</option>
            <option value="100">100 per halaman</option>
          </select>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-bordered table-hover" id="tabelRekening">
          <thead class="table-light">
            <tr>
              <th width="30%">Kode Rekening</th>
              <th width="60%">Nama Belanja</th>
              <th width="10%">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <!-- Data akan diisi oleh JavaScript -->
          </tbody>
        </table>
      </div>

      <!-- Pagination Controls -->
      <div class="row mt-3">
        <div class="col-md-6">
          <div class="pagination-info" data-tipe="rekening"></div>
        </div>
        <div class="col-md-6">
          <nav>
            <ul class="pagination justify-content-end pagination-controls" data-tipe="rekening"></ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Duplicate Confirmation Modal -->
<div class="modal fade" id="duplicateModal" tabindex="-1" aria-labelledby="duplicateModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-warning">
        <h5 class="modal-title" id="duplicateModalLabel">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="me-2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          Konfirmasi Kode Rekening Sama
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="alert alert-warning">
          <strong>Kode rekening yang Anda input sudah digunakan!</strong>
          <br>Kode ini sudah terdaftar dengan nama belanja yang berbeda.
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="card border-warning">
              <div class="card-header bg-warning text-dark">
                <strong>Data yang Sudah Ada</strong>
              </div>
              <div class="card-body">
                <div id="existingDataList">
                  <!-- Data existing akan diisi oleh JavaScript -->
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card border-primary">
              <div class="card-header bg-primary text-white">
                <strong>Data Baru yang Akan Disimpan</strong>
              </div>
              <div class="card-body">
                <table class="table table-sm">
                  <tr>
                    <td width="40%"><strong>Kode Rekening:</strong></td>
                    <td><code id="newKode">-</code></td>
                  </tr>
                  <tr>
                    <td><strong>Nama Belanja:</strong></td>
                    <td id="newNama">-</td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="mt-3">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="forceSave">
            <label class="form-check-label text-danger" for="forceSave">
              <strong>Ya, saya ingin menyimpan data baru dengan kode rekening yang sama</strong>
            </label>
          </div>
          <small class="text-muted">
            Data lama akan tetap ada. Sistem mengizinkan beberapa nama belanja dengan kode yang sama.
          </small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-warning" id="confirmDuplicate" disabled>
          <span class="spinner-border spinner-border-sm d-none" role="status"></span>
          Simpan Data Baru
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Apakah Anda yakin ingin menghapus data rekening & belanja ini?</p>
        <p class="text-muted small">Data yang sudah digunakan tidak dapat dihapus.</p>
        <input type="hidden" id="deleteId">
        <input type="hidden" id="deleteTipe" value="rekening">
        <input type="hidden" id="deleteCsrf" value="<?= $_SESSION['csrf_token'] ?>">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-danger" id="confirmDelete">
          <span class="spinner-border spinner-border-sm d-none" role="status"></span>
          Hapus
        </button>
      </div>
    </div>
  </div>
</div>

<script>
    const BASEURL = '<?= BASEURL ?>';
    const tableState = {
        rekening: { page: 1, per_page: 10, search: '', search_field: '' }
    };
    let pendingFormData = null;

    // ==================== GLOBAL FUNCTIONS ====================
    function showAlert(message, type = 'success') {
        const alert = `<div class="alert alert-${type} alert-dismissible fade show" data-aos="zoom-in">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
        $('#alertContainer').html(alert);

        // Auto hide after 5 seconds
        setTimeout(() => $('#alertContainer .alert').alert('close'), 5000);
    }

    function resetFormRekening() {
        $('#formRekening')[0].reset();
        $('#rekening_id').val('');
        $('#formRekening button[type="submit"]').text('Simpan');
        clearValidationErrors('rekening');
    }

    function clearValidationErrors(prefix = '') {
        if (prefix) {
            $(`#${prefix}_kode_rekening`).removeClass('is-invalid');
            $(`#${prefix}_nama_belanja`).removeClass('is-invalid');
            $(`#${prefix}_kode_rekening_error`).text('');
            $(`#${prefix}_nama_belanja_error`).text('');
        } else {
            $('.is-invalid').removeClass('is-invalid');
            $('.invalid-feedback').text('');
        }
    }

    function showValidationErrors(errors, prefix = '') {
        for (const field in errors) {
            const fieldId = prefix ? `${prefix}_${field}` : field;
            $(`#${fieldId}`).addClass('is-invalid');
            $(`#${fieldId}_error`).text(errors[field]);
        }
    }

    function cleanupStuckModals() {
        $('.modal-backdrop').remove();
        $('body').removeClass('modal-open');
        $('.modal').hide();
        $('body').css({'overflow': '', 'padding-right': ''});
    }

    // Update function showDuplicateModal untuk handle multiple existing data
    function showDuplicateModal(existingData, newData) {
        // Isi data baru
        $('#newKode').text(newData.kode_rekening || '-');
        $('#newNama').text(newData.nama_belanja || '-');

        // Isi data existing (bisa multiple)
        let existingHtml = '';
        if (Array.isArray(existingData)) {
            existingData.forEach((item, index) => {
                existingHtml += `
                    <div class="mb-2 p-2 border rounded ${index > 0 ? 'mt-2' : ''}">
                        <table class="table table-sm mb-0">
                            <tr>
                                <td width="40%"><strong>Kode Rekening:</strong></td>
                                <td><code>${item.kode_rekening || '-'}</code></td>
                            </tr>
                            <tr>
                                <td><strong>Nama Belanja:</strong></td>
                                <td>${item.nama_belanja || '-'}</td>
                            </tr>
                        </table>
                    </div>
                `;
            });
        } else {
            existingHtml = `
                <table class="table table-sm">
                    <tr>
                        <td width="40%"><strong>Kode Rekening:</strong></td>
                        <td><code>${existingData.kode_rekening || '-'}</code></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Belanja:</strong></td>
                        <td>${existingData.nama_belanja || '-'}</td>
                    </tr>
                </table>
            `;
        }

        $('#existingDataList').html(existingHtml);

        // Reset checkbox dan button
        $('#forceSave').prop('checked', false);
        $('#confirmDuplicate').prop('disabled', true);

        // Show modal
        $('#duplicateModal').modal('show');
        cleanupStuckModals();
    }

    // Load table data dengan pagination dan search
    function loadTableData(tipe) {
        const state = tableState[tipe];
        const tableId = `tabel${tipe.charAt(0).toUpperCase() + tipe.slice(1)}`;

        $(`#${tableId} tbody`).html(`
            <tr>
                <td colspan="3" class="text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </td>
            </tr>
        `);

        $.ajax({
            url: BASEURL + "admin/rekening_belanja",
            method: 'POST',
            data: {
                a: "data",
                page: state.page,
                per_page: state.per_page,
                search: state.search,
                search_field: state.search_field
            },
            dataType: 'json',
            success: function(res) {
                if (res.status === "success") {
                    let tbody = $(`#${tableId} tbody`).empty();

                    if (res.data.length === 0) {
                        tbody.append(`
                            <tr>
                                <td colspan="3" class="text-center py-4">
                                    <div class="text-muted">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" class="mb-2">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <line x1="12" y1="8" x2="12" y2="12"></line>
                                            <line x1="12" y1="16" x2="12.01" y2="16"></line>
                                        </svg>
                                        <br>
                                        ${state.search ? 'Tidak ada data yang sesuai dengan pencarian' : 'Belum ada data rekening & belanja'}
                                    </div>
                                </td>
                            </tr>
                        `);
                    } else {
                        res.data.forEach(row => {
                            let tr = $("<tr>");
                            tr.append($("<td>").html(`<code class="text-primary">${row.kode_rekening || ''}</code>`));
                            tr.append($("<td>").text(row.nama_belanja || ''));

                            let actions = `
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-primary btn-edit" data-id="${row.id}" title="Edit">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M12 20h9"></path>
                                            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                                        </svg>
                                    </button>
                                    <button class="btn btn-outline-danger btn-delete" data-id="${row.id}" title="Hapus">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="3 6 5 6 21 6"></polyline>
                                            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                        </svg>
                                    </button>
                                </div>
                            `;
                            tr.append($("<td>").html(actions));
                            tbody.append(tr);
                        });
                    }

                    // Update pagination controls
                    updatePaginationControls(tipe, res.pagination);
                } else {
                    showAlert("Gagal memuat data: " + res.message, 'danger');
                }
            },
            error: function(xhr, status, error) {
                showAlert("Server error saat mengambil data.", 'danger');
            }
        });
    }

    // Update pagination controls
    function updatePaginationControls(tipe, pagination) {
        const { current_page, per_page, total_rows, total_pages } = pagination;

        // Update pagination info
        const start = ((current_page - 1) * per_page) + 1;
        const end = Math.min(current_page * per_page, total_rows);
        $(`.pagination-info[data-tipe="${tipe}"]`).html(`
            Menampilkan ${start} - ${end} dari ${total_rows} data
        `);

        // Update pagination buttons
        const paginationEl = $(`.pagination-controls[data-tipe="${tipe}"]`).empty();

        // Previous button
        paginationEl.append(`
            <li class="page-item ${current_page === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${current_page - 1}">‹</a>
            </li>
        `);

        // Page buttons
        const maxVisiblePages = 5;
        let startPage = Math.max(1, current_page - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(total_pages, startPage + maxVisiblePages - 1);

        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }

        for (let i = startPage; i <= endPage; i++) {
            paginationEl.append(`
                <li class="page-item ${i === current_page ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>
            `);
        }

        // Next button
        paginationEl.append(`
            <li class="page-item ${current_page === total_pages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${current_page + 1}">›</a>
            </li>
        `);
    }

    // Event handlers untuk pagination
    $(document).on('click', '.pagination-controls .page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        const tipe = $(this).closest('.pagination-controls').data('tipe');

        if (page) {
            tableState[tipe].page = page;
            loadTableData(tipe);
        }
    });

    // Event handlers untuk search
    $(document).on('click', '.search-btn', function() {
        const tipe = $(this).data('tipe');
        const searchInput = $(`.search-input[data-tipe="${tipe}"]`);
        const searchField = $(`.search-field-select[data-tipe="${tipe}"]`);

        tableState[tipe].search = searchInput.val();
        tableState[tipe].search_field = searchField.val();
        tableState[tipe].page = 1;

        loadTableData(tipe);
    });

    $(document).on('keypress', '.search-input', function(e) {
        if (e.which === 13) {
            const tipe = $(this).data('tipe');
            $(`.search-btn[data-tipe="${tipe}"]`).click();
        }
    });

    // Event handlers untuk per page change
    $(document).on('change', '.per-page-select', function() {
        const tipe = $(this).data('tipe');
        tableState[tipe].per_page = $(this).val();
        tableState[tipe].page = 1;
        loadTableData(tipe);
    });

    $(document).ready(function() {
        // Load initial data
        loadTableData('rekening');

        // Form submission handler
        $("#formRekening").submit(function(e) {
            e.preventDefault();
            submitForm('rekening');
        });

        // Edit button handler
        $(document).on("click", ".btn-edit", function() {
            const id = $(this).data("id");
            editData(id);
        });

        // Delete button handler
        $(document).on("click", ".btn-delete", function() {
            const id = $(this).data("id");
            $("#deleteId").val(id);
            $("#deleteModal").modal("show");
            cleanupStuckModals();
        });

        // Confirm delete
        $("#confirmDelete").click(function() {
            const deleteBtn = $(this);
            const id = $("#deleteId").val();
            const csrfToken = $("#deleteCsrf").val();

            deleteBtn.prop('disabled', true);
            deleteBtn.find('.spinner-border').removeClass('d-none');

            $.ajax({
                url: BASEURL + "admin/rekening_belanja",
                method: 'POST',
                data: {
                    a: "hapus",
                    id: id,
                    csrf_token: csrfToken
                },
                dataType: 'json',
                success: function(res) {
                    deleteBtn.prop('disabled', false);
                    deleteBtn.find('.spinner-border').addClass('d-none');

                    if (res.status === "success") {
                        $("#deleteModal").modal("hide");
                        showAlert(res.message, 'success');
                        loadTableData('rekening');
                    } else {
                        showAlert("Gagal hapus: " + res.message, 'danger');
                    }
                },
                error: function(xhr, status, error) {
                    deleteBtn.prop('disabled', false);
                    deleteBtn.find('.spinner-border').addClass('d-none');
                    showAlert("Server error saat menghapus.", 'danger');
                }
            });
        });
    });

    // Handle checkbox change
    $('#forceSave').on('change', function() {
        $('#confirmDuplicate').prop('disabled', !$(this).is(':checked'));
    });

    // Handle duplicate confirmation
    $('#confirmDuplicate').click(function() {
        if (!pendingFormData) return;

        const confirmBtn = $(this);
        confirmBtn.prop('disabled', true);
        confirmBtn.find('.spinner-border').removeClass('d-none');

        // Tambahkan flag untuk force save
        pendingFormData.force_save = '1';

        $.ajax({
            url: BASEURL + "admin/rekening_belanja",
            method: 'POST',
            data: pendingFormData,
            dataType: 'json',
            success: function(res) {
                confirmBtn.prop('disabled', false);
                confirmBtn.find('.spinner-border').addClass('d-none');

                if (res.status === "success") {
                    $('#duplicateModal').modal('hide');
                    showAlert(res.message, 'success');
                    loadTableData('rekening');

                    // Reset form
                    $('#formRekening')[0].reset();
                    $('#rekening_id').val('');
                    $('#formRekening button[type="submit"]').text('Simpan');

                    $('html, body').animate({ scrollTop: 0 }, 500);
                } else {
                    showAlert("Gagal simpan: " + res.message, 'danger');
                }
            },
            error: function(xhr, status, error) {
                confirmBtn.prop('disabled', false);
                confirmBtn.find('.spinner-border').addClass('d-none');
                showAlert("Server error saat menyimpan.", 'danger');
            }
        });
    });

    function submitForm(tipe) {
        clearValidationErrors(tipe);

        const form = $(`#form${tipe.charAt(0).toUpperCase() + tipe.slice(1)}`);
        const formData = form.serializeArray();
        const data = {};
        formData.forEach(f => data[f.name] = f.value);

        // Hapus force_save flag jika ada dari sebelumnya
        delete data.force_save;

        // Show loading state
        const submitBtn = form.find('button[type="submit"]');
        submitBtn.prop('disabled', true);
        submitBtn.find('.spinner-border').removeClass('d-none');

        $.ajax({
            url: BASEURL + "admin/rekening_belanja",
            method: 'POST',
            data: data,
            dataType: 'json',
            success: function(res) {
                submitBtn.prop('disabled', false);
                submitBtn.find('.spinner-border').addClass('d-none');

                if (res.status === "success") {
                    // Success case - reset form and reload data
                    form[0].reset();
                    $(`#${tipe}_id`).val('');
                    submitBtn.text('Simpan');
                    showAlert(res.message, 'success');
                    loadTableData(tipe);
                    $('html, body').animate({ scrollTop: 0 }, 500);
                } else if (res.status === "warning") {
                    // Kode rekening exists with different nama belanja - show warning modal
                    pendingFormData = data; // Simpan data untuk nanti
                    showDuplicateModal(res.existing_data, res.new_data);
                } else {
                    if (res.errors) {
                        showValidationErrors(res.errors, tipe);
                    } else {
                        showAlert("Gagal simpan: " + res.message, 'danger');
                    }
                }
            },
            error: function(xhr, status, error) {
                submitBtn.prop('disabled', false);
                submitBtn.find('.spinner-border').addClass('d-none');
                showAlert("Server error saat menyimpan.", 'danger');
            }
        });
    }

    function editData(id) {
        clearValidationErrors('rekening');

        $.ajax({
            url: BASEURL + "admin/rekening_belanja",
            method: 'POST',
            data: {
                a: "get",
                id: id
            },
            dataType: 'json',
            success: function(res) {
                if (res.status === "success") {
                    const item = res.data;
                    const form = $('#formRekening');

                    // Fill form with data
                    $('#rekening_id').val(item.id);
                    $('#rekening_kode_rekening').val(item.kode_rekening);
                    $('#rekening_nama_belanja').val(item.nama_belanja);

                    form.find('button[type="submit"]').text('Update');

                    // Scroll to form
                    $('html, body').animate({
                        scrollTop: form.offset().top - 100
                    }, 500);
                } else {
                    showAlert("Gagal mengambil data: " + res.message, 'danger');
                }
            },
            error: function(xhr, status, error) {
                showAlert("Server error saat mengambil data.", 'danger');
            }
        });
    }
</script>

<link rel="stylesheet" href="assets/css/rekening_admin.css">
<?php
}